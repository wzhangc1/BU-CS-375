I, Williams Zhang Cen, have done this assignment completely on my own. I have not copied it, nor
have I given my solution to anyone else. I understand that if I am involved in plagiarism or
cheating I will have to sign an official form that I have cheated and that this form will be stored in
my official university record. I also understand that I will receive a grade of 0 for the involved
assignment for my first offense and that I will receive a grade of “F” for the course for any
additional offense.

Run by:
	make
	./program2 filex.txt filey.txt output2.txt

Use:
	Recursion

Time:
	O(n^2)

Classes:
	None

Functions:
	Main - calls lcs
	lcs - recursively calculate LCS without memorization

Variables
	fin - input file
	time - time complexity
	fout - output file
	first - first string
	second - second string
